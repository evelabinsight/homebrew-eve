eve Homebrew package

Run:
  eve --help
