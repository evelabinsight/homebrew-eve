#!/usr/bin/env python3
import asyncio
import argparse
import hashlib
import http.client
import inspect
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path


DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 17888
DEFAULT_PREFIX = "/api/v1"
DEFAULT_REQUEST_TIMEOUT = 5
INSTALL_REQUEST_TIMEOUT = 300
EXPORT_REQUEST_TIMEOUT = 600
DETECT_IMAGE_REQUEST_TIMEOUT = 900
BUILD_ARCHIVE_DOWNLOAD_TIMEOUT = 600
UPLOAD_CHUNK_SIZE = 256 * 1024
DOWNLOAD_CHUNK_SIZE = 256 * 1024
MATCH_BROADCAST_MESSAGE = "where is the Eve？"
MATCH_BROADCAST_INTERVAL = 2
MATCH_TIMEOUT_SECONDS = 10
MATCH_PROGRESS_REFRESH_SECONDS = 0.2
BLE_SCAN_STEP_SECONDS = 2
BLE_SCAN_TIMEOUT_SECONDS = 15
BLE_WIFI_TIMEOUT_SECONDS = 60
BLE_WIFI_CONNECTED_GRACE_SECONDS = 5
BLE_PROGRESS_REFRESH_SECONDS = 0.2
REQUEST_PROGRESS_REFRESH_SECONDS = 0.2
BLE_REQUEST_CONNECT_WIFI = 0x00
BLE_RESULT_TYPE_CONNECT_STATE = 0x00
BLE_RESULT_TYPE_WIFI_CONNECT_RESULT = 0x01
BLE_RESULT_TYPE_WIFI_MAC_ADDRESS = 0x03
BLE_RESULT_TYPE_WIFI_CONNECT_STATE = 0x04
BLE_RESULT_TYPE_WIFI_CONNECT_FAIL_REASON = 0x05
BLE_RESULT_SUCCESS = 0
BLE_PROTOCOL_VERSION = 290
DEVICE_TYPE_RULES = (
    ("M2025", "M_s", 16070),
    ("Muse", "Muse_", 24530),
    ("V", "V_", 27530),
    ("M", "M_", 6070),
)
BLE_DEVICE_RULES = {
    "Muse": {
        "device_name_prefix": "Muse_",
        "service_uuid": "10000003-1000-0000-0000-000005320520",
        "characteristic_uuid": "10000003-0000-1000-0000-000005320520",
        "descriptor_uuid": "10000003-0000-0000-1000-000005320520",
    },
    "V": {
        "device_name_prefix": "meitu_king_",
        "service_uuid": "10000002-1000-0000-0000-000005320520",
        "characteristic_uuid": "10000002-0000-1000-0000-000005320520",
        "descriptor_uuid": "10000002-0000-0000-1000-000005320520",
    },
}
WIFI_FAIL_REASON_MESSAGES = {
    0: "Wi-Fi 密码错误",
    1: "Wi-Fi 搜索失败",
    2: "Wi-Fi 获取 IP 失败",
    3: "Wi-Fi 配置失败",
    4: "Wi-Fi 不可用",
    5: "Wi-Fi 认证失败",
    -1: "Wi-Fi 连接超时",
}
CONFIG_DIR = Path.home() / ".eve"
CONFIG_FILE = CONFIG_DIR / "config.json"
LOCAL_DOWNLOADS_DIR = Path.home() / "Downloads"
LOCAL_COMPLETE_DIR = LOCAL_DOWNLOADS_DIR / "complete"
LOCAL_LOGS_DIR = LOCAL_DOWNLOADS_DIR / "logs"
AVAILABLE_COMMANDS = {
    "ping": "连通性检测",
    "echo": "回显传入参数",
    "app.status": "获取应用当前状态",
    "version": "获取设备版本号信息",
    "take_picture": "触发拍照流程",
    "install": "支持本地 APK 路径或 build 号安装升级",
    "export_complete": "拉取设备全部成片文件到本机 Downloads/complete",
    "log": "拉取左右从机和中机日志到本机 Downloads/logs",
    "detect_image": "导入原图目录并返回检测结果到输入路径同级的 RERUN",
    "detect_images": "批量检测多套原图并汇总成功失败结果",
}
LOCAL_COMMAND_HELP = "\n".join(
    [
        "  match <设备DeviceId>     自动匹配设备并保存默认 DeviceId 与地址",
        "  wifi --ssid ... --password ... [--device-id ...]",
        "                         通过蓝牙为设备配置 Wi-Fi 账号和密码",
        "  config set-host <地址>   保存默认设备地址到本地配置",
    ]
)
MATCH_PROGRESS_FRAMES = ("|", "/", "-", "\\")
BLE_DESCRIPTOR_ENABLE_NOTIFICATION_VALUE = b"\x01\x00"
BLE_POLL_INTERVAL_SECONDS = 0.5
WIFI_HELPER_NAME = "eve-wifi"
BUILD_ARCHIVE_URLS = {
    "Muse": "http://172.21.19.152:8080/job/Muse/{build}/artifact/*zip*/archive.zip",
    "V": "http://172.21.19.152:8080/job/MTKing/{build}/artifact/*zip*/archive.zip",
    "M": "http://172.21.19.152:8080/job/M2025/{build}/artifact/*zip*/archive.zip",
    "M2025": "http://172.21.19.152:8080/job/M2025/{build}/artifact/*zip*/archive.zip",
}
BUILD_APK_DIRECTORY_PREFIXES = (
    "archive/app/build/outputs/apk/db/release/",
    "archive/app/build/outputs/apk/mp/release/",
    "app/build/outputs/apk/db/release/",
    "app/build/outputs/apk/mp/release/",
)
DETECT_IMAGE_REQUIRED_RELATIVE_PATHS = tuple(
    [
        "group_default/capture/Middle/1_nose_original.jpg",
        "group_open_eye_0/capture/Middle/1_nose_original.jpg",
        *(
            f"group_default/capture/{folder}/{light}_original.jpg"
            for light in (1, 2, 3, 4)
            for folder in ("Left", "Middle", "Right")
        ),
        *(
            f"group_default/capture/{folder}/1_original.jpg"
            for folder in ("Left_Chin", "Right_Chin")
        ),
        *(
            f"group_open_eye_0/capture/{folder}/1_original.jpg"
            for folder in ("Left", "Middle", "Right", "Left_Chin", "Right_Chin")
        ),
    ]
)


def make_base_url(host: str, port: int, prefix: str) -> str:
    return f"http://{host}:{port}{prefix.rstrip('/')}"


def get_device_type_rule(device_id: str):
    normalized_device_id = device_id.strip()
    for device_type, prefix, broadcast_port in DEVICE_TYPE_RULES:
        if normalized_device_id.startswith(prefix):
            return {
                "device_type": device_type,
                "prefix": prefix,
                "broadcast_port": broadcast_port,
            }
    return None


def validate_device_id(device_id: str) -> str:
    normalized_device_id = device_id.strip()
    if not normalized_device_id or get_device_type_rule(normalized_device_id) is None:
        raise SystemExit("输入的设备ID不合法")
    return normalized_device_id


def extract_device_token_id(device_id: str) -> str:
    normalized_device_id = validate_device_id(device_id)
    return normalized_device_id[-6:]


def generate_token_from_device_id(device_id: str) -> str:
    token_device_id = extract_device_token_id(device_id)
    return hashlib.sha256(f"evelink:{token_device_id}".encode("utf-8")).hexdigest()


def request_json(
    method: str,
    url: str,
    payload=None,
    token=None,
    body=None,
    content_type=None,
    timeout=DEFAULT_REQUEST_TIMEOUT,
):
    data = body
    headers = {"Accept": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
        headers["X-Evelink-Token"] = token
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    elif content_type:
        headers["Content-Type"] = content_type
    req = urllib.request.Request(url=url, method=method, data=data, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            charset = response.headers.get_content_charset() or "utf-8"
            body = response.read().decode(charset)
            return json.loads(body)
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {body}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Request failed: {exc.reason}") from exc


def print_json(payload):
    print(json.dumps(payload, indent=2, ensure_ascii=False))


def load_binary_file(file_path: str):
    path = Path(file_path).expanduser()
    if not path.is_file():
        raise SystemExit(f"APK 文件不存在: {path}")
    return path


def is_build_number_target(target: str) -> bool:
    return target.strip().isdigit()


def format_size(size: int) -> str:
    if size < 1024:
        return f"{size}B"
    if size < 1024 * 1024:
        return f"{size / 1024:.1f}KB"
    return f"{size / (1024 * 1024):.1f}MB"


def render_upload_progress(sent_bytes: int, total_bytes: int):
    total = max(total_bytes, 1)
    percent = min(sent_bytes / total, 1.0)
    bar_width = 24
    filled = int(bar_width * percent)
    bar = "#" * filled + "-" * (bar_width - filled)
    message = (
        f"\r上传进度 [{bar}] {percent * 100:6.2f}% "
        f"{format_size(sent_bytes)}/{format_size(total_bytes)}"
    )
    print(message, end="", file=sys.stderr, flush=True)


def render_download_progress(received_bytes: int, total_bytes: int):
    total = max(total_bytes, 1)
    percent = min(received_bytes / total, 1.0)
    bar_width = 24
    filled = int(bar_width * percent)
    bar = "#" * filled + "-" * (bar_width - filled)
    if total_bytes > 0:
        message = (
            f"\r下载进度 [{bar}] {percent * 100:6.2f}% "
            f"{format_size(received_bytes)}/{format_size(total_bytes)}"
        )
    else:
        message = f"\r已下载 {format_size(received_bytes)}"
    print(message, end="", file=sys.stderr, flush=True)


def render_match_progress(
    device_type: str,
    broadcast_port: int,
    elapsed_seconds: float,
    frame_index: int,
):
    spinner = MATCH_PROGRESS_FRAMES[frame_index % len(MATCH_PROGRESS_FRAMES)]
    message = (
        f"\r正在匹配设备 {spinner} "
        f"类型: {device_type} 端口: {broadcast_port} "
        f"已等待: {elapsed_seconds:4.1f}s/{MATCH_TIMEOUT_SECONDS}s"
    )
    print(message, end="", file=sys.stderr, flush=True)


def render_ble_progress(
    stage: str,
    detail: str,
    elapsed_seconds: float,
    total_seconds: float,
    frame_index: int,
):
    spinner = MATCH_PROGRESS_FRAMES[frame_index % len(MATCH_PROGRESS_FRAMES)]
    message = (
        f"\r{stage} {spinner} "
        f"{detail} 已等待: {elapsed_seconds:4.1f}s/{total_seconds}s"
    )
    print(message, end="", file=sys.stderr, flush=True)


def render_wait_progress(
    stage: str,
    detail: str,
    elapsed_seconds: float,
    total_seconds: float,
    frame_index: int,
):
    spinner = MATCH_PROGRESS_FRAMES[frame_index % len(MATCH_PROGRESS_FRAMES)]
    suffix = ""
    if total_seconds > 0:
        suffix = f" 已等待: {elapsed_seconds:4.1f}s/{total_seconds}s"
    elif elapsed_seconds > 0:
        suffix = f" 已等待: {elapsed_seconds:4.1f}s"
    message = f"\r{stage} {spinner} {detail}{suffix}"
    print(message, end="", file=sys.stderr, flush=True)


def print_stderr_line(message: str):
    print(f"\r{message}", file=sys.stderr, flush=True)


def run_with_wait_progress(operation, stage: str, detail: str, total_seconds: int):
    state = {"result": None, "error": None}
    done_event = threading.Event()

    def worker():
        try:
            state["result"] = operation()
        except BaseException as exc:  # noqa: BLE001
            state["error"] = exc
        finally:
            done_event.set()

    thread = threading.Thread(target=worker, daemon=True)
    thread.start()

    started_at = time.monotonic()
    frame_index = 0
    showed_progress = False
    while not done_event.wait(REQUEST_PROGRESS_REFRESH_SECONDS):
        showed_progress = True
        render_wait_progress(
            stage=stage,
            detail=detail,
            elapsed_seconds=time.monotonic() - started_at,
            total_seconds=total_seconds,
            frame_index=frame_index,
        )
        frame_index += 1

    if showed_progress:
        print("", file=sys.stderr, flush=True)

    if state["error"] is not None:
        raise state["error"]
    return state["result"]


def request_install_with_progress(file_path: Path, url: str, token: str, timeout: int):
    parsed = urllib.parse.urlsplit(url)
    connection = http.client.HTTPConnection(parsed.hostname, parsed.port, timeout=timeout)
    request_path = parsed.path
    if parsed.query:
        request_path = f"{request_path}?{parsed.query}"

    file_size = file_path.stat().st_size
    headers = {
        "Accept": "application/json",
        "Authorization": f"Bearer {token}",
        "X-Evelink-Token": token,
        "Content-Type": "application/octet-stream",
        "Content-Length": str(file_size),
    }
    try:
        connection.putrequest("POST", request_path)
        for key, value in headers.items():
            connection.putheader(key, value)
        connection.endheaders()

        sent_bytes = 0
        with file_path.open("rb") as fh:
            while True:
                chunk = fh.read(UPLOAD_CHUNK_SIZE)
                if not chunk:
                    break
                connection.send(chunk)
                sent_bytes += len(chunk)
                render_upload_progress(sent_bytes, file_size)
        print("\n上传完成，等待设备响应...", file=sys.stderr, flush=True)

        response = connection.getresponse()
        body = response.read().decode(response.headers.get_content_charset() or "utf-8")
        if response.status >= 400:
            raise RuntimeError(f"HTTP {response.status}: {body}")
        return json.loads(body)
    except OSError as exc:
        raise RuntimeError(f"Request failed: {exc}") from exc
    finally:
        connection.close()


def download_file_with_progress(url: str, target_path: Path, timeout: int):
    req = urllib.request.Request(url=url, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            total_bytes = response.headers.get("Content-Length")
            total_size = int(total_bytes) if total_bytes and total_bytes.isdigit() else 0
            received_bytes = 0
            with open(target_path, "wb") as output:
                while True:
                    chunk = response.read(DOWNLOAD_CHUNK_SIZE)
                    if not chunk:
                        break
                    output.write(chunk)
                    received_bytes += len(chunk)
                    render_download_progress(received_bytes, total_size)
        print("", file=sys.stderr)
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"下载构建包失败，HTTP {exc.code}: {body}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"下载构建包失败: {exc.reason}") from exc


def get_build_archive_url(device_id: str, build_number: str) -> str:
    device_type_rule = get_device_type_rule(device_id)
    if device_type_rule is None:
        raise SystemExit("输入的设备ID不合法")
    device_type = device_type_rule["device_type"]
    template = BUILD_ARCHIVE_URLS.get(device_type)
    if not template:
        raise SystemExit(f"当前设备类型暂不支持通过 build 号安装: {device_type}")
    return template.format(build=build_number)


def choose_archive_apk(apk_names):
    if not apk_names:
        raise RuntimeError(
            "压缩包中未找到 archive/app/build/outputs/apk/db/release 或 "
            "archive/app/build/outputs/apk/mp/release 目录下的 APK"
        )

    def sort_key(name: str):
        lower_name = name.lower()
        return (
            "unaligned" in lower_name,
            "test" in lower_name,
            len(lower_name),
            lower_name,
        )

    return sorted(apk_names, key=sort_key)[0]


def extract_apk_from_archive(zip_path: Path, output_dir: Path) -> Path:
    with zipfile.ZipFile(zip_path) as archive:
        apk_names = [
            info.filename
            for info in archive.infolist()
            if not info.is_dir()
            and any(
                info.filename.startswith(prefix)
                for prefix in BUILD_APK_DIRECTORY_PREFIXES
            )
            and info.filename.lower().endswith(".apk")
        ]
        selected_name = choose_archive_apk(apk_names)
        output_path = output_dir / Path(selected_name).name
        with archive.open(selected_name) as source, open(output_path, "wb") as target:
            shutil.copyfileobj(source, target)
    return output_path


def resolve_install_file(target: str, device_id: str):
    expanded_path = Path(target).expanduser()
    if expanded_path.is_file():
        return expanded_path, None

    if not is_build_number_target(target):
        raise SystemExit(
            "install 命令需要提供本地 APK 文件路径或构建号，例如：eve install /path/app.apk 或 eve install 12345"
        )

    build_number = target.strip()
    download_url = get_build_archive_url(device_id, build_number)
    temp_dir = Path(tempfile.mkdtemp(prefix="eve-install-build-"))
    zip_path = temp_dir / f"{build_number}.zip"

    print_stderr_line(f"正在下载构建包: {build_number}")
    download_file_with_progress(download_url, zip_path, BUILD_ARCHIVE_DOWNLOAD_TIMEOUT)
    print_stderr_line("正在从压缩包中提取 APK...")
    apk_path = extract_apk_from_archive(zip_path, temp_dir)
    print_stderr_line(f"已提取 APK: {apk_path.name}")
    return apk_path, temp_dir


def resolve_detect_image_archive(target: str):
    path = Path(target).expanduser()
    if not path.exists():
        raise SystemExit(f"detect_image 输入路径不存在: {path}")

    if path.is_file() and path.suffix.lower() == ".zip":
        return path, None

    temp_dir = Path(tempfile.mkdtemp(prefix="eve-detect-image-"))
    archive_path = temp_dir / f"{path.stem or 'detect_image'}.zip"
    if path.is_dir():
        files = [item for item in path.rglob("*") if item.is_file()]
        if not files:
            shutil.rmtree(temp_dir, ignore_errors=True)
            raise SystemExit(f"detect_image 输入目录没有文件: {path}")
        with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as archive:
            for item in files:
                archive.write(item, item.relative_to(path))
        return archive_path, temp_dir

    if not path.is_file():
        shutil.rmtree(temp_dir, ignore_errors=True)
        raise SystemExit(f"detect_image 输入路径不是文件或目录: {path}")

    with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.write(path, path.name)
    return archive_path, temp_dir


def resolve_detect_image_output_dir(target: str) -> Path:
    path = Path(target).expanduser()
    input_name = path.name if path.is_dir() or not path.suffix else path.stem
    output_name = input_name.replace("ORIGINAL", "RERUN") if "ORIGINAL" in input_name else "RERUN"
    return path.parent / output_name


def resolve_detect_images_output_dir(case_path: Path) -> Path:
    input_name = case_path.name if case_path.is_dir() or not case_path.suffix else case_path.stem
    if "ORIGINAL" in input_name:
        output_name = input_name.replace("ORIGINAL", "RERUN")
    else:
        output_name = f"{input_name}_RERUN"
    return case_path.parent / output_name


def is_detect_images_output_path(path: Path) -> bool:
    upper_parts = [part.upper() for part in path.parts]
    return any(part == "RERUN" or part.endswith("_RERUN") for part in upper_parts)


def has_detect_image_group_dir(path: Path) -> bool:
    return (path / "group_default").is_dir() or (path / "group_open_eye_0").is_dir()


def get_missing_detect_image_files(directory: Path):
    missing = []
    for relative_path in DETECT_IMAGE_REQUIRED_RELATIVE_PATHS:
        if not (directory / relative_path).is_file():
            missing.append(relative_path)
    return missing


def get_missing_detect_image_zip_files(zip_path: Path):
    try:
        with zipfile.ZipFile(zip_path, "r") as archive:
            names = {
                info.filename.rstrip("/")
                for info in archive.infolist()
                if not info.is_dir()
            }
    except zipfile.BadZipFile as exc:
        raise RuntimeError(f"zip 文件格式错误: {zip_path}") from exc

    missing = []
    for relative_path in DETECT_IMAGE_REQUIRED_RELATIVE_PATHS:
        if relative_path not in names and f"ORIGINAL/{relative_path}" not in names:
            missing.append(relative_path)
    return missing


def make_detect_images_failure(case_path: Path, reason: str, missing_files=None):
    return {
        "name": case_path.name,
        "input": str(case_path),
        "reason": reason,
        "missingFiles": missing_files or [],
    }


def find_detect_images_candidates(target: str):
    root = Path(target).expanduser()
    if not root.exists():
        raise SystemExit(f"detect_images 输入路径不存在: {root}")
    if root.is_file():
        if root.suffix.lower() == ".zip":
            return [root]
        raise SystemExit("detect_images 输入路径需要是目录或 zip 文件")
    if not root.is_dir():
        raise SystemExit(f"detect_images 输入路径不是目录: {root}")

    candidates = []
    for current, dirs, _ in os.walk(root):
        current_path = Path(current)
        dirs[:] = [
            directory
            for directory in dirs
            if not is_detect_images_output_path(current_path / directory)
        ]
        if is_detect_images_output_path(current_path):
            dirs[:] = []
            continue
        if has_detect_image_group_dir(current_path):
            candidates.append(current_path)
            dirs[:] = []

    for current, dirs, files in os.walk(root):
        current_path = Path(current)
        dirs[:] = [
            directory
            for directory in dirs
            if not is_detect_images_output_path(current_path / directory)
        ]
        if is_detect_images_output_path(current_path):
            dirs[:] = []
            continue
        if current_path.name == "ORIGINAL" and files:
            candidates.append(current_path)

    zip_candidates = [
        item
        for item in root.rglob("*.zip")
        if item.is_file() and not is_detect_images_output_path(item)
    ]
    return sorted({*candidates, *zip_candidates}, key=lambda item: str(item))


def request_detect_images(
    target: str,
    url: str,
    token: str,
    timeout: int,
):
    candidates = find_detect_images_candidates(target)
    if not candidates:
        return {
            "total": 0,
            "successCount": 0,
            "failureCount": 1,
            "success": [],
            "failed": [
                {
                    "name": Path(target).expanduser().name,
                    "input": str(Path(target).expanduser()),
                    "reason": "未找到可检测的图片集目录",
                    "missingFiles": [],
                }
            ],
        }

    success = []
    failed = []
    for index, case_path in enumerate(candidates, start=1):
        print_stderr_line(f"[{index}/{len(candidates)}] 检查图片集: {case_path}")
        try:
            if case_path.is_file():
                missing_files = get_missing_detect_image_zip_files(case_path)
            else:
                missing_files = get_missing_detect_image_files(case_path)
        except Exception as exc:  # noqa: BLE001
            failed.append(make_detect_images_failure(case_path, f"读取检测资源失败: {exc}"))
            continue
        if missing_files:
            failed.append(
                make_detect_images_failure(
                    case_path,
                    f"检测资源不完整，已跳过，缺少 {len(missing_files)} 个文件",
                    missing_files,
                )
            )
            continue

        archive_path = None
        cleanup_dir = None
        try:
            archive_path, cleanup_dir = resolve_detect_image_archive(str(case_path))
            target_dir = resolve_detect_images_output_dir(case_path)
            detect_url = (
                f"{url}?filename={urllib.parse.quote(archive_path.name)}"
            )
            result = request_detect_image(
                archive_file=archive_path,
                url=detect_url,
                token=token,
                timeout=timeout,
                target_dir=target_dir,
            )
            success.append(
                {
                    "name": case_path.name,
                    "input": str(case_path),
                    "savedTo": result.get("savedTo"),
                    "sourceDir": result.get("sourceDir"),
                    "files": result.get("files", []),
                }
            )
        except Exception as exc:  # noqa: BLE001
            failed.append(make_detect_images_failure(case_path, f"设备检测失败: {exc}"))
        finally:
            if cleanup_dir is not None:
                shutil.rmtree(cleanup_dir, ignore_errors=True)

    return {
        "total": len(candidates),
        "successCount": len(success),
        "failureCount": len(failed),
        "success": success,
        "failed": failed,
    }


def ensure_clean_directory(directory: Path):
    if directory.exists():
        shutil.rmtree(directory)
    directory.mkdir(parents=True, exist_ok=True)


def normalize_extracted_complete_dir(temp_extract_dir: Path, target_dir: Path):
    extracted_root = temp_extract_dir / "complete"
    target_dir.parent.mkdir(parents=True, exist_ok=True)
    if extracted_root.is_dir():
        shutil.move(str(extracted_root), str(target_dir))
        return

    ensure_clean_directory(target_dir)
    for child in temp_extract_dir.iterdir():
        shutil.move(str(child), str(target_dir / child.name))


def normalize_extracted_named_dir(temp_extract_dir: Path, target_dir: Path, root_name: str):
    extracted_root = temp_extract_dir / root_name
    target_dir.parent.mkdir(parents=True, exist_ok=True)
    if extracted_root.is_dir():
        merge_directory_contents(extracted_root, target_dir)
        return

    merge_directory_contents(temp_extract_dir, target_dir)


def merge_directory_contents(source_dir: Path, target_dir: Path):
    target_dir.mkdir(parents=True, exist_ok=True)
    for child in source_dir.iterdir():
        target_path = target_dir / child.name
        if child.is_dir() and not child.is_symlink():
            if target_path.is_dir() and not target_path.is_symlink():
                merge_directory_contents(child, target_path)
                shutil.rmtree(child)
            else:
                replace_path(child, target_path)
        else:
            replace_path(child, target_path)


def replace_path(source_path: Path, target_path: Path):
    if target_path.is_dir() and not target_path.is_symlink() and source_path.is_file():
        source_path.unlink()
        return
    if target_path.exists() or target_path.is_symlink():
        if target_path.is_dir() and not target_path.is_symlink():
            shutil.rmtree(target_path)
        else:
            target_path.unlink()
    shutil.move(str(source_path), str(target_path))


def request_complete_export(url: str, token: str, timeout: int, target_dir: Path):
    headers = {"Accept": "application/zip"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
        headers["X-Evelink-Token"] = token
    payload = b"{}"
    headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url=url, method="POST", data=payload, headers=headers)

    archive_path = None
    extract_dir = None
    source_dir = None
    try:
        LOCAL_DOWNLOADS_DIR.mkdir(parents=True, exist_ok=True)
        with urllib.request.urlopen(request, timeout=timeout) as response:
            content_type = response.headers.get_content_type()
            if content_type != "application/zip":
                body = response.read().decode(
                    response.headers.get_content_charset() or "utf-8",
                    errors="replace",
                )
                raise RuntimeError(f"设备返回了非 zip 响应: {body}")

            source_dir = response.headers.get("X-Eve-Source-Dir")
            total_bytes = int(response.headers.get("Content-Length", "0") or 0)
            with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as temp_file:
                archive_path = Path(temp_file.name)
                received_bytes = 0
                while True:
                    chunk = response.read(DOWNLOAD_CHUNK_SIZE)
                    if not chunk:
                        break
                    temp_file.write(chunk)
                    received_bytes += len(chunk)
                    render_download_progress(received_bytes, total_bytes)

        print("\n下载完成，正在解压到本机 Downloads/complete ...", file=sys.stderr, flush=True)
        if archive_path is None:
            raise RuntimeError("未收到导出文件")

        if target_dir.exists():
            shutil.rmtree(target_dir)
        extract_dir = Path(tempfile.mkdtemp(prefix="eve_complete_"))
        with zipfile.ZipFile(archive_path, "r") as archive:
            archive.extractall(extract_dir)
        normalize_extracted_complete_dir(extract_dir, target_dir)
        return {
            "savedTo": str(target_dir),
            "sourceDir": source_dir,
            "archiveSize": archive_path.stat().st_size,
        }
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {body}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Request failed: {exc.reason}") from exc
    finally:
        if archive_path and archive_path.exists():
            archive_path.unlink()
        if extract_dir and extract_dir.exists():
            shutil.rmtree(extract_dir)


def request_log_export(url: str, token: str, timeout: int, target_dir: Path):
    headers = {"Accept": "application/zip"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
        headers["X-Evelink-Token"] = token
    payload = b"{}"
    headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url=url, method="POST", data=payload, headers=headers)

    archive_path = None
    extract_dir = None
    source_dir = None
    file_names = None
    failures = None
    try:
        LOCAL_DOWNLOADS_DIR.mkdir(parents=True, exist_ok=True)
        response_context = run_with_wait_progress(
            operation=lambda: urllib.request.urlopen(request, timeout=timeout),
            stage="正在等待设备打包日志",
            detail="",
            total_seconds=timeout,
        )
        with response_context as response:
            content_type = response.headers.get_content_type()
            if content_type != "application/zip":
                body = response.read().decode(
                    response.headers.get_content_charset() or "utf-8",
                    errors="replace",
                )
                raise RuntimeError(f"设备返回了非 zip 响应: {body}")

            source_dir = response.headers.get("X-Eve-Source-Dir")
            file_names = response.headers.get("X-Eve-Log-Files")
            failures = response.headers.get("X-Eve-Log-Failures")
            total_bytes = int(response.headers.get("Content-Length", "0") or 0)
            with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as temp_file:
                archive_path = Path(temp_file.name)
                received_bytes = 0
                while True:
                    chunk = response.read(DOWNLOAD_CHUNK_SIZE)
                    if not chunk:
                        break
                    temp_file.write(chunk)
                    received_bytes += len(chunk)
                    render_download_progress(received_bytes, total_bytes)

        print("\n下载完成，正在解压到本机 Downloads/logs ...", file=sys.stderr, flush=True)
        if archive_path is None:
            raise RuntimeError("未收到日志导出文件")

        ensure_clean_directory(target_dir)
        extract_dir = Path(tempfile.mkdtemp(prefix="eve_logs_"))
        with zipfile.ZipFile(archive_path, "r") as archive:
            archive.extractall(extract_dir)
        for child in extract_dir.iterdir():
            shutil.move(str(child), str(target_dir / child.name))
        return {
            "savedTo": str(target_dir),
            "sourceDir": source_dir,
            "archiveSize": archive_path.stat().st_size,
            "files": file_names.split(",") if file_names else [],
            "failures": failures or "",
        }
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {body}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Request failed: {exc.reason}") from exc
    finally:
        if archive_path and archive_path.exists():
            archive_path.unlink()
        if extract_dir and extract_dir.exists():
            shutil.rmtree(extract_dir)


def request_detect_image(
    archive_file: Path,
    url: str,
    token: str,
    timeout: int,
    target_dir: Path,
):
    parsed = urllib.parse.urlsplit(url)
    connection = http.client.HTTPConnection(parsed.hostname, parsed.port, timeout=timeout)
    request_path = parsed.path
    if parsed.query:
        request_path = f"{request_path}?{parsed.query}"

    archive_size = archive_file.stat().st_size
    headers = {
        "Accept": "application/zip",
        "Authorization": f"Bearer {token}",
        "X-Evelink-Token": token,
        "Content-Type": "application/zip",
        "Content-Length": str(archive_size),
    }
    result_archive_path = None
    extract_dir = None
    source_dir = None
    file_names = None
    try:
        connection.putrequest("POST", request_path)
        for key, value in headers.items():
            connection.putheader(key, value)
        connection.endheaders()

        sent_bytes = 0
        with archive_file.open("rb") as fh:
            while True:
                chunk = fh.read(UPLOAD_CHUNK_SIZE)
                if not chunk:
                    break
                connection.send(chunk)
                sent_bytes += len(chunk)
                render_upload_progress(sent_bytes, archive_size)
        print("\n上传完成，等待设备检测并返回结果...", file=sys.stderr, flush=True)

        response = run_with_wait_progress(
            operation=connection.getresponse,
            stage="正在等待设备检测",
            detail="",
            total_seconds=timeout,
        )
        content_type = response.headers.get_content_type()
        if response.status >= 400:
            body = response.read().decode(
                response.headers.get_content_charset() or "utf-8",
                errors="replace",
            )
            raise RuntimeError(f"HTTP {response.status}: {body}")
        if content_type != "application/zip":
            body = response.read().decode(
                response.headers.get_content_charset() or "utf-8",
                errors="replace",
            )
            raise RuntimeError(f"设备返回了非 zip 响应: {body}")

        source_dir = response.headers.get("X-Eve-Source-Dir")
        file_names = response.headers.get("X-Eve-Detect-Files")
        total_bytes = int(response.headers.get("Content-Length", "0") or 0)
        with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as temp_file:
            result_archive_path = Path(temp_file.name)
            received_bytes = 0
            while True:
                chunk = response.read(DOWNLOAD_CHUNK_SIZE)
                if not chunk:
                    break
                temp_file.write(chunk)
                received_bytes += len(chunk)
                render_download_progress(received_bytes, total_bytes)

        print(f"\n下载完成，正在解压到本机 {target_dir} ...", file=sys.stderr, flush=True)
        extract_dir = Path(tempfile.mkdtemp(prefix="eve_detect_image_"))
        with zipfile.ZipFile(result_archive_path, "r") as archive:
            archive.extractall(extract_dir)
        normalize_extracted_named_dir(extract_dir, target_dir, "RERUN")
        return {
            "savedTo": str(target_dir),
            "sourceDir": source_dir,
            "archiveSize": result_archive_path.stat().st_size,
            "files": file_names.split(",") if file_names else [],
        }
    except OSError as exc:
        raise RuntimeError(f"Request failed: {exc}") from exc
    finally:
        connection.close()
        if result_archive_path and result_archive_path.exists():
            result_archive_path.unlink()
        if extract_dir and extract_dir.exists():
            shutil.rmtree(extract_dir)


def load_local_config():
    if not CONFIG_FILE.exists():
        return {}
    try:
        with CONFIG_FILE.open("r", encoding="utf-8") as fh:
            payload = json.load(fh)
    except OSError as exc:
        raise SystemExit(f"读取本地配置失败: {exc}") from exc
    except json.JSONDecodeError as exc:
        raise SystemExit(f"本地配置文件不是合法 JSON: {CONFIG_FILE}: {exc}") from exc
    if not isinstance(payload, dict):
        raise SystemExit(f"本地配置文件格式错误: {CONFIG_FILE}")
    return payload


def save_local_config(payload):
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        with CONFIG_FILE.open("w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2)
            fh.write("\n")
    except OSError as exc:
        raise SystemExit(f"写入本地配置失败: {exc}") from exc


def resolve_default_device_id(config):
    env_device_id = (
        os.environ.get("EVE_DEVICE_ID")
        or os.environ.get("EVE_DEVICE_SN")
        or os.environ.get("EVELINK_DEVICE_SN")
    )
    if env_device_id:
        return env_device_id
    config_device_id = config.get("device_id") or config.get("device_sn")
    if isinstance(config_device_id, str) and config_device_id.strip():
        return config_device_id.strip()
    return None


def resolve_default_host(config):
    env_host = os.environ.get("DEVICEKING_HOST")
    if env_host:
        return env_host
    config_host = config.get("host")
    if isinstance(config_host, str) and config_host.strip():
        return config_host.strip()
    return DEFAULT_HOST


def normalize_match_suffix(value: str) -> str:
    return value.strip().upper()[-6:]


def get_ble_device_rule(device_id: str):
    normalized_device_id = validate_device_id(device_id)
    device_type_rule = get_device_type_rule(normalized_device_id)
    device_type = device_type_rule["device_type"]
    ble_rule = BLE_DEVICE_RULES.get(device_type)
    if ble_rule is None:
        raise SystemExit("当前仅支持 Muse 和 V 设备通过蓝牙配置 Wi-Fi")
    return ble_rule


def get_ble_device_name(device_id: str) -> str:
    normalized_device_id = validate_device_id(device_id)
    ble_rule = get_ble_device_rule(normalized_device_id)
    return f"{ble_rule['device_name_prefix']}{extract_device_token_id(normalized_device_id)}"


def get_ble_dependency():
    try:
        from bleak import BleakClient, BleakScanner
    except ImportError as exc:
        raise SystemExit(
            "当前环境缺少蓝牙依赖，请先执行: python3 -m pip install --user bleak"
        ) from exc
    return BleakClient, BleakScanner


def describe_ble_device(device, advertisement_data=None):
    names = []
    service_uuids = []
    if device is not None:
        device_name = getattr(device, "name", None)
        if isinstance(device_name, str) and device_name.strip():
            names.append(device_name.strip())
    if advertisement_data is not None:
        local_name = getattr(advertisement_data, "local_name", None)
        if isinstance(local_name, str) and local_name.strip():
            names.append(local_name.strip())
        advertisement_service_uuids = getattr(advertisement_data, "service_uuids", None)
        if isinstance(advertisement_service_uuids, (list, tuple, set)):
            service_uuids.extend(
                str(service_uuid).lower()
                for service_uuid in advertisement_service_uuids
                if service_uuid
            )
    address = getattr(device, "address", None) or "unknown"
    deduplicated_names = list(dict.fromkeys(names))
    deduplicated_service_uuids = list(dict.fromkeys(service_uuids))
    return address, deduplicated_names, deduplicated_service_uuids


def is_matching_ble_name(name: str, expected_name: str, accepted_prefixes, expected_suffix: str):
    normalized_name = name.strip().lower()
    if not normalized_name:
        return False

    if normalized_name == expected_name.lower():
        return True

    if not normalized_name.endswith(expected_suffix.lower()):
        return False

    return any(normalized_name.startswith(prefix.lower()) for prefix in accepted_prefixes)


def match_ble_discovered_device(
    discovered,
    expected_name: str,
    accepted_prefixes,
    expected_suffix: str,
    expected_service_uuid: str,
):
    if isinstance(discovered, dict):
        iterator = discovered.values()
    else:
        iterator = ((item, None) for item in discovered)

    for item in iterator:
        if isinstance(item, tuple) and len(item) == 2:
            device, advertisement_data = item
        else:
            device, advertisement_data = item, None

        _, names, service_uuids = describe_ble_device(device, advertisement_data)
        for name in names:
            if is_matching_ble_name(name, expected_name, accepted_prefixes, expected_suffix):
                return device
        if expected_service_uuid.lower() in service_uuids:
            for name in names:
                if name.strip().lower().endswith(expected_suffix.lower()):
                    return device
    return None


def summarize_ble_scan_candidates(discovered):
    if isinstance(discovered, dict):
        iterator = discovered.values()
    else:
        iterator = ((item, None) for item in discovered)

    candidates = []
    for item in iterator:
        if isinstance(item, tuple) and len(item) == 2:
            device, advertisement_data = item
        else:
            device, advertisement_data = item, None
        address, names, service_uuids = describe_ble_device(device, advertisement_data)
        if not names and not service_uuids:
            continue
        labels = []
        if names:
            labels.append("/".join(names))
        if service_uuids:
            labels.append(",".join(service_uuids))
        candidates.append(f"{address} [{' | '.join(labels)}]")
        if len(candidates) >= 5:
            break
    return candidates


async def animate_ble_scan_progress(device_type: str, started_at: float, stop_event):
    frame_index = 0
    while not stop_event.is_set():
        render_ble_progress(
            stage="正在扫描蓝牙设备",
            detail=f"类型: {device_type}",
            elapsed_seconds=time.monotonic() - started_at,
            total_seconds=BLE_SCAN_TIMEOUT_SECONDS,
            frame_index=frame_index,
        )
        frame_index += 1
        await asyncio.sleep(BLE_PROGRESS_REFRESH_SECONDS)


async def discover_ble_device(device_id: str):
    _, BleakScanner = get_ble_dependency()
    ble_rule = get_ble_device_rule(device_id)
    expected_name = get_ble_device_name(device_id)
    service_uuid = ble_rule["service_uuid"]
    expected_suffix = extract_device_token_id(device_id)
    device_type_rule = get_device_type_rule(device_id)
    accepted_prefixes = (
        ble_rule["device_name_prefix"],
        device_type_rule["prefix"],
    )
    device_type = device_type_rule["device_type"]

    started_at = time.monotonic()
    deadline = started_at + BLE_SCAN_TIMEOUT_SECONDS
    last_discovered = None
    stop_event = asyncio.Event()
    progress_task = asyncio.create_task(
        animate_ble_scan_progress(
            device_type=device_type,
            started_at=started_at,
            stop_event=stop_event,
        )
    )

    try:
        while True:
            now = time.monotonic()
            if now >= deadline:
                break

            remaining = deadline - now
            scan_timeout = min(BLE_SCAN_STEP_SECONDS, max(remaining, 0.1))
            try:
                try:
                    discovered = await BleakScanner.discover(
                        timeout=scan_timeout,
                        return_adv=True,
                    )
                except TypeError:
                    discovered = await BleakScanner.discover(timeout=scan_timeout)
            except Exception as exc:
                print("", file=sys.stderr)
                raise RuntimeError(f"扫描蓝牙设备失败: {exc}") from exc

            last_discovered = discovered
            matched_device = match_ble_discovered_device(
                discovered=discovered,
                expected_name=expected_name,
                accepted_prefixes=accepted_prefixes,
                expected_suffix=expected_suffix,
                expected_service_uuid=service_uuid,
            )
            if matched_device is not None:
                print("", file=sys.stderr)
                return matched_device
    finally:
        stop_event.set()
        await progress_task

    print("", file=sys.stderr)
    timeout_message = (
        f"蓝牙扫描超时，未找到目标设备。请确认设备蓝牙已开启，且 DeviceId 后六位为 {expected_suffix}。"
    )
    candidates = summarize_ble_scan_candidates(last_discovered)
    if candidates:
        timeout_message += "\n附近扫描到的设备示例:\n- " + "\n- ".join(candidates)
    raise SystemExit(timeout_message)


def format_ble_fail_reason(payload):
    data = payload.get("data") or {}
    reason_type = data.get("reasonType")
    reason_message = WIFI_FAIL_REASON_MESSAGES.get(reason_type, "Wi-Fi 连接失败")
    detailed_state = data.get("detailedState")
    disable_reason = data.get("disableReasonString")

    parts = [reason_message]
    if isinstance(detailed_state, str) and detailed_state:
        parts.append(f"状态: {detailed_state}")
    if isinstance(disable_reason, str) and disable_reason:
        parts.append(f"原因: {disable_reason}")
    return "，".join(parts)


def handle_ble_notification(payload, result_future, runtime_state):
    result_type = payload.get("resultType")
    result_code = payload.get("resultCode")
    message = payload.get("msg") or ""

    if result_type == BLE_RESULT_TYPE_CONNECT_STATE:
        if result_code != BLE_RESULT_SUCCESS and not result_future.done():
            result_future.set_exception(RuntimeError(message or "设备当前不可接收蓝牙请求"))
        elif message:
            print_stderr_line(f"设备响应: {message}")
        return

    if result_type == BLE_RESULT_TYPE_WIFI_CONNECT_STATE:
        data = payload.get("data") or {}
        state = data.get("state")
        extra_info = data.get("extraInfo")
        parts = []
        if data.get("isAvailable") is True:
            runtime_state["wifi_connected"] = True
            if runtime_state.get("wifi_connected_at") is None:
                runtime_state["wifi_connected_at"] = time.monotonic()
        if isinstance(state, str) and state:
            parts.append(state)
            if "CONNECTED/CONNECTED" in state:
                runtime_state["wifi_connected"] = True
                if runtime_state.get("wifi_connected_at") is None:
                    runtime_state["wifi_connected_at"] = time.monotonic()
        if isinstance(extra_info, str) and extra_info:
            parts.append(extra_info)
        if parts:
            print_stderr_line(f"Wi-Fi 状态: {' / '.join(parts)}")
        return

    if result_type == BLE_RESULT_TYPE_WIFI_MAC_ADDRESS:
        runtime_state["received_wifi_mac"] = True
        if runtime_state.get("wifi_connected"):
            runtime_state["wifi_success_signal"] = True
        return

    if result_type == BLE_RESULT_TYPE_WIFI_CONNECT_FAIL_REASON and not result_future.done():
        result_future.set_exception(RuntimeError(format_ble_fail_reason(payload)))
        return

    if result_type == BLE_RESULT_TYPE_WIFI_CONNECT_RESULT and not result_future.done():
        if result_code == BLE_RESULT_SUCCESS:
            runtime_state["wifi_success_signal"] = True
            result_future.set_result(payload)
        else:
            result_future.set_exception(RuntimeError(message or "Wi-Fi 连接失败"))


class BleWifiConnectedFallback(Exception):
    pass


async def wait_with_ble_progress(result_future, stage: str, total_seconds: int, runtime_state=None):
    started_at = time.monotonic()
    frame_index = 0

    while True:
        if result_future.done():
            return await result_future

        elapsed = time.monotonic() - started_at
        if elapsed >= total_seconds:
            raise TimeoutError

        if runtime_state and runtime_state.get("wifi_connected"):
            connected_at = runtime_state.get("wifi_connected_at")
            if connected_at is not None:
                connected_elapsed = time.monotonic() - connected_at
                if connected_elapsed >= BLE_WIFI_CONNECTED_GRACE_SECONDS:
                    raise BleWifiConnectedFallback

        render_ble_progress(
            stage=stage,
            detail="",
            elapsed_seconds=elapsed,
            total_seconds=total_seconds,
            frame_index=frame_index,
        )
        frame_index += 1
        await asyncio.sleep(BLE_PROGRESS_REFRESH_SECONDS)


def find_ble_descriptor(characteristic, descriptor_uuid: str):
    descriptors = getattr(characteristic, "descriptors", None) or []
    expected_descriptor_uuid = descriptor_uuid.lower()
    for descriptor in descriptors:
        current_uuid = getattr(descriptor, "uuid", None)
        if isinstance(current_uuid, str) and current_uuid.lower() == expected_descriptor_uuid:
            return descriptor
    return None


async def resolve_ble_services(client):
    get_services = getattr(client, "get_services", None)
    if callable(get_services):
        services = get_services()
        if inspect.isawaitable(services):
            services = await services
        if services is not None:
            return services

    services = getattr(client, "services", None)
    if services is not None:
        return services

    raise RuntimeError("当前 bleak 版本未返回蓝牙服务列表，请升级 bleak 后重试")


def find_ble_service(services, service_uuid: str):
    get_service = getattr(services, "get_service", None)
    if callable(get_service):
        service = get_service(service_uuid)
        if service is not None:
            return service

    for service in services:
        current_uuid = getattr(service, "uuid", None)
        if isinstance(current_uuid, str) and current_uuid.lower() == service_uuid.lower():
            return service
    return None


def find_ble_characteristic(service, characteristic_uuid: str):
    get_characteristic = getattr(service, "get_characteristic", None)
    if callable(get_characteristic):
        characteristic = get_characteristic(characteristic_uuid)
        if characteristic is not None:
            return characteristic

    characteristics = getattr(service, "characteristics", None) or []
    for characteristic in characteristics:
        current_uuid = getattr(characteristic, "uuid", None)
        if isinstance(current_uuid, str) and current_uuid.lower() == characteristic_uuid.lower():
            return characteristic
    return None


async def poll_ble_responses(client, characteristic_specifier, result_future, runtime_state):
    last_payload = None
    while not result_future.done():
        try:
            payload_bytes = await client.read_gatt_char(characteristic_specifier)
        except Exception:
            await asyncio.sleep(BLE_POLL_INTERVAL_SECONDS)
            continue

        payload_bytes = bytes(payload_bytes or b"")
        if not payload_bytes or payload_bytes == last_payload:
            await asyncio.sleep(BLE_POLL_INTERVAL_SECONDS)
            continue

        last_payload = payload_bytes
        try:
            payload = json.loads(payload_bytes.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            await asyncio.sleep(BLE_POLL_INTERVAL_SECONDS)
            continue

        if isinstance(payload, dict):
            handle_ble_notification(payload, result_future, runtime_state)

        await asyncio.sleep(BLE_POLL_INTERVAL_SECONDS)


def make_ble_success_payload(device_id: str, host: str = "", source: str = "ble_state"):
    data = {
        "ssid": "",
        "isOpenNetwork": False,
        "rssi": 0,
        "ip": host,
        "bssid": "",
        "macAddress": "",
        "gatewayIp": "",
    }
    return {
        "resultType": BLE_RESULT_TYPE_WIFI_CONNECT_RESULT,
        "resultCode": BLE_RESULT_SUCCESS,
        "msg": "wifi连接成功",
        "data": data,
        "meta": {
            "resolvedBy": source,
            "deviceId": device_id,
        },
    }


async def connect_wifi_over_ble_async(device_id: str, ssid: str, password: str):
    BleakClient, _ = get_ble_dependency()
    ble_rule = get_ble_device_rule(device_id)
    service_uuid = ble_rule["service_uuid"]
    characteristic_uuid = ble_rule["characteristic_uuid"]
    descriptor_uuid = ble_rule["descriptor_uuid"]
    ble_device = await discover_ble_device(device_id)
    expected_name = get_ble_device_name(device_id)

    print_stderr_line(f"已找到蓝牙设备: {expected_name}")
    print_stderr_line("正在连接蓝牙设备...")

    try:
        async with BleakClient(ble_device) as client:
            result_future = asyncio.get_running_loop().create_future()
            runtime_state = {
                "wifi_connected": False,
                "wifi_connected_at": None,
                "wifi_success_signal": False,
                "received_wifi_mac": False,
            }
            services = await resolve_ble_services(client)
            service = find_ble_service(services, service_uuid)
            if service is None:
                raise RuntimeError(f"未找到蓝牙服务: {service_uuid}")

            characteristic = find_ble_characteristic(service, characteristic_uuid)
            if characteristic is None:
                raise RuntimeError(f"未找到蓝牙特征: {characteristic_uuid}")

            descriptor = find_ble_descriptor(characteristic, descriptor_uuid)
            if descriptor is None:
                raise RuntimeError(f"未找到蓝牙描述符: {descriptor_uuid}")

            await client.write_gatt_descriptor(
                descriptor.handle,
                BLE_DESCRIPTOR_ENABLE_NOTIFICATION_VALUE,
            )

            request_payload = {
                "requestType": BLE_REQUEST_CONNECT_WIFI,
                "protocolVersion": BLE_PROTOCOL_VERSION,
                "data": {
                    "ssid": ssid,
                    "countryCode": "",
                    "securityType": 0,
                    "psw": password,
                },
            }
            poll_task = asyncio.create_task(
                poll_ble_responses(
                    client,
                    characteristic_uuid,
                    result_future,
                    runtime_state,
                )
            )
            await client.write_gatt_char(
                characteristic_uuid,
                json.dumps(request_payload, ensure_ascii=False).encode("utf-8"),
                response=True,
            )

            try:
                result_payload = await wait_with_ble_progress(
                    result_future,
                    stage="正在等待设备配网结果",
                    total_seconds=BLE_WIFI_TIMEOUT_SECONDS,
                    runtime_state=runtime_state,
                )
                print("", file=sys.stderr)
                return result_payload
            except BleWifiConnectedFallback:
                print("", file=sys.stderr)
                print_stderr_line("已检测到设备 Wi-Fi 连通，正在尝试解析设备地址...")
                try:
                    match_result = try_match_device_by_device_id(device_id)
                    print_stderr_line(f"已解析到设备地址: {match_result['host']}")
                    return make_ble_success_payload(
                        device_id=device_id,
                        host=match_result["host"],
                        source="udp_match",
                    )
                except SystemExit:
                    print_stderr_line("未能自动解析设备地址，但设备已连上 Wi-Fi")
                    return make_ble_success_payload(
                        device_id=device_id,
                        host="",
                        source="ble_state",
                    )
            except TimeoutError as exc:
                print("", file=sys.stderr)
                if runtime_state.get("wifi_connected"):
                    print_stderr_line("已检测到设备 Wi-Fi 连通，正在尝试解析设备地址...")
                    try:
                        match_result = try_match_device_by_device_id(device_id)
                        print_stderr_line(f"已解析到设备地址: {match_result['host']}")
                        return make_ble_success_payload(
                            device_id=device_id,
                            host=match_result["host"],
                            source="udp_match",
                        )
                    except SystemExit:
                        print_stderr_line("未能自动解析设备地址，但设备已连上 Wi-Fi")
                        return make_ble_success_payload(
                            device_id=device_id,
                            host="",
                            source="ble_state",
                        )
                raise RuntimeError("等待设备 Wi-Fi 配网结果超时") from exc
            finally:
                poll_task.cancel()
                try:
                    await poll_task
                except asyncio.CancelledError:
                    pass
    except RuntimeError:
        raise
    except Exception as exc:
        raise RuntimeError(
            f"蓝牙连接或配网失败: {exc}。请确认终端已授予蓝牙权限，且设备蓝牙已开启。"
        ) from exc


def connect_wifi_over_ble(device_id: str, ssid: str, password: str):
    return asyncio.run(connect_wifi_over_ble_async(device_id, ssid, password))


def try_match_device_by_device_id(device_id: str):
    normalized_device_id = validate_device_id(device_id)
    device_type_rule = get_device_type_rule(normalized_device_id)
    broadcast_port = device_type_rule["broadcast_port"]
    device_type = device_type_rule["device_type"]

    expected_suffix = normalize_match_suffix(normalized_device_id)
    started_at = time.monotonic()
    deadline = started_at + MATCH_TIMEOUT_SECONDS
    next_send_time = 0.0
    frame_index = 0
    payload = MATCH_BROADCAST_MESSAGE.encode("utf-8")

    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

        while True:
            now = time.monotonic()
            if now >= deadline:
                break

            render_match_progress(
                device_type=device_type,
                broadcast_port=broadcast_port,
                elapsed_seconds=now - started_at,
                frame_index=frame_index,
            )
            frame_index += 1

            if now >= next_send_time:
                sock.sendto(payload, ("255.255.255.255", broadcast_port))
                next_send_time = now + MATCH_BROADCAST_INTERVAL

            recv_timeout = min(MATCH_PROGRESS_REFRESH_SECONDS, max(deadline - now, 0.01))
            sock.settimeout(recv_timeout)
            try:
                data, address = sock.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError as exc:
                raise SystemExit(f"发送或接收 UDP 广播失败: {exc}") from exc

            try:
                response = json.loads(data.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                continue

            if not isinstance(response, dict):
                continue

            ssid = response.get("ssid")
            if not isinstance(ssid, str) or not ssid.strip():
                continue

            if normalize_match_suffix(ssid) != expected_suffix:
                continue

            print("", file=sys.stderr)
            return {
                "host": address[0],
                "ssid": ssid.strip(),
                "device_id": normalized_device_id,
                "device_type": device_type_rule["device_type"],
                "broadcast_port": broadcast_port,
            }

    print("", file=sys.stderr)
    raise SystemExit("匹配超时，未匹配到设备")


def handle_local_command(argv):
    if not argv:
        return None

    config = load_local_config()

    if argv[0] == "match":
        if len(argv) != 2:
            raise SystemExit("用法: eve match <设备DeviceId>")
        device_id = validate_device_id(argv[1])
        config["device_id"] = device_id
        config.pop("device_sn", None)
        save_local_config(config)
        print(f"已保存默认设备 DeviceId: {device_id}")
        print(f"配置文件: {CONFIG_FILE}")

        match_result = try_match_device_by_device_id(device_id)
        config["host"] = match_result["host"]
        save_local_config(config)
        print(
            f"匹配设备类型: {match_result['device_type']} "
            f"(广播端口 {match_result['broadcast_port']})"
        )
        print(f"匹配成功，设备 SSID: {match_result['ssid']}")
        print(f"已保存默认设备地址: {match_result['host']}")
        return 0

    if argv[0] == "wifi":
        return invoke_wifi_helper(argv[1:])

    if argv[0] != "config":
        return None

    if len(argv) == 1 or argv[1] in ("-h", "--help"):
        print("用法:")
        print("  eve match <设备DeviceId>")
        print("  eve wifi --ssid <Wi-Fi账号> --password <Wi-Fi密码> [--device-id <设备DeviceId>]")
        print("  eve config set-host <设备IP或主机名>")
        print("说明: 保存默认设备参数到本地配置文件 ~/.eve/config.json")
        return 0

    if len(argv) != 3:
        raise SystemExit(
            "用法: eve match <设备DeviceId>、eve wifi --ssid <Wi-Fi账号> --password <Wi-Fi密码> [--device-id <设备DeviceId>] "
            "或 eve config set-host <设备IP或主机名>"
        )

    if argv[1] == "set-host":
        host = argv[2].strip()
        if not host:
            raise SystemExit("设备地址不能为空")
        config["host"] = host
        save_local_config(config)
        print(f"已保存默认设备地址: {host}")
    else:
        raise SystemExit("不支持的 config 子命令，目前仅支持: set-host")

    print(f"配置文件: {CONFIG_FILE}")
    return 0


def build_parser(default_host, default_device_id):
    command_help = "\n".join(
        f"  {name:<12} {description}" for name, description in AVAILABLE_COMMANDS.items()
    )
    parser = argparse.ArgumentParser(
        description="Eve 设备控制工具",
        epilog=f"可用命令:\n{command_help}\n\n本地命令:\n{LOCAL_COMMAND_HELP}",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser.add_argument("--host", default=default_host, help="设备 IP 或主机名")
    parser.add_argument(
        "--device-id",
        "--sn",
        dest="device_id",
        default=default_device_id,
        help="设备 DeviceId，工具会在内部用它推导鉴权 token",
    )
    parser.add_argument("name", help="要执行的命令名")
    parser.add_argument(
        "--data",
        default="{}",
        help="命令参数，JSON 对象格式，默认值为 {}",
    )
    parser.add_argument(
        "target",
        nargs="?",
        help="install 使用 APK 路径或构建号；detect_image/detect_images 使用原图目录或 zip 路径",
    )
    return parser


def build_wifi_parser(default_device_id):
    wifi_parser = argparse.ArgumentParser(
        prog="eve wifi",
        description="通过蓝牙为设备配置 Wi-Fi 账号和密码",
    )
    wifi_parser.add_argument(
        "--device-id",
        default=default_device_id,
        help="设备 DeviceId，默认读取本地配置或环境变量",
    )
    wifi_parser.add_argument("--ssid", required=True, help="Wi-Fi 账号")
    wifi_parser.add_argument("--password", required=True, help="Wi-Fi 密码")
    return wifi_parser


def run_wifi_command(argv, config):
    wifi_parser = build_wifi_parser(resolve_default_device_id(config))
    wifi_args = wifi_parser.parse_args(argv)

    device_id = wifi_args.device_id
    if not device_id:
        raise SystemExit(
            "缺少设备 DeviceId，请先执行 eve match <设备DeviceId>，或通过 --device-id 传入"
        )

    if not wifi_args.ssid:
        raise SystemExit("Wi-Fi 账号不能为空")
    if wifi_args.password == "":
        raise SystemExit("Wi-Fi 密码不能为空")

    device_id = validate_device_id(device_id)
    result_payload = connect_wifi_over_ble(
        device_id=device_id,
        ssid=wifi_args.ssid,
        password=wifi_args.password,
    )
    data = result_payload.get("data") or {}
    config["device_id"] = device_id
    config.pop("device_sn", None)

    local_ip = data.get("ip")
    if isinstance(local_ip, str) and local_ip.strip():
        config["host"] = local_ip.strip()
    save_local_config(config)

    print(f"已通过蓝牙发送 Wi-Fi 配置，目标设备: {device_id}")
    print(f"Wi-Fi 账号: {wifi_args.ssid}")
    if isinstance(local_ip, str) and local_ip.strip():
        print(f"设备局域网地址: {local_ip.strip()}")
        print(f"已保存默认设备地址: {local_ip.strip()}")
    print(f"已保存默认设备 DeviceId: {device_id}")
    print(f"配置文件: {CONFIG_FILE}")
    return 0


def resolve_wifi_helper_command():
    helper_dir = Path(sys.executable if getattr(sys, "frozen", False) else __file__).resolve().parent
    helper_path = helper_dir / WIFI_HELPER_NAME
    if not helper_path.exists():
        return None
    if os.access(helper_path, os.X_OK):
        return [str(helper_path)]
    return [sys.executable, str(helper_path)]


def invoke_wifi_helper(argv):
    helper_command = resolve_wifi_helper_command()
    if helper_command is None:
        return run_wifi_command(argv, load_local_config())

    completed = subprocess.run([*helper_command, *argv], check=False)
    return completed.returncode


def main_wifi_helper(argv=None):
    argv = list(argv or sys.argv[1:])
    return run_wifi_command(argv, load_local_config())


def main(argv=None):
    argv = list(argv or sys.argv[1:])
    local_command_result = handle_local_command(argv)
    if local_command_result is not None:
        return local_command_result

    config = load_local_config()
    parser = build_parser(
        resolve_default_host(config),
        resolve_default_device_id(config),
    )
    args = parser.parse_args(argv)
    base_url = make_base_url(args.host, DEFAULT_PORT, DEFAULT_PREFIX)
    normalized_device_id = None
    if args.device_id:
        normalized_device_id = validate_device_id(args.device_id)
    token = generate_token_from_device_id(normalized_device_id) if normalized_device_id else None

    if not token:
        raise SystemExit(
            "缺少设备 DeviceId，请通过 --device-id 传入，或设置环境变量 EVE_DEVICE_ID"
        )

    if args.name == "install":
        if not args.target:
            raise SystemExit(
                "install 命令需要提供本地 APK 文件路径或构建号，例如：eve install /path/app.apk 或 eve install 12345"
            )
        file_path = None
        cleanup_dir = None
        try:
            file_path, cleanup_dir = resolve_install_file(args.target, normalized_device_id)
            install_url = (
                f"{base_url}/commands/install"
                f"?filename={urllib.parse.quote(file_path.name)}"
            )
            result = request_install_with_progress(
                file_path=file_path,
                url=install_url,
                token=token,
                timeout=INSTALL_REQUEST_TIMEOUT,
            )
        finally:
            if cleanup_dir is not None:
                shutil.rmtree(cleanup_dir, ignore_errors=True)
    elif args.name == "export_complete":
        if args.target:
            raise SystemExit("export_complete 命令不接受额外文件路径参数")
        export_url = f"{base_url}/commands/export_complete"
        result = request_complete_export(
            url=export_url,
            token=token,
            timeout=EXPORT_REQUEST_TIMEOUT,
            target_dir=LOCAL_COMPLETE_DIR,
        )
    elif args.name == "log":
        if args.target:
            raise SystemExit("log 命令不接受额外文件路径参数")
        export_url = f"{base_url}/commands/log"
        result = request_log_export(
            url=export_url,
            token=token,
            timeout=EXPORT_REQUEST_TIMEOUT,
            target_dir=LOCAL_LOGS_DIR,
        )
    elif args.name == "detect_image":
        if not args.target:
            raise SystemExit(
                "detect_image 命令需要提供本地原图目录、zip 或图片文件路径，例如：eve detect_image /path/ORIGINAL"
            )
        archive_path = None
        cleanup_dir = None
        try:
            archive_path, cleanup_dir = resolve_detect_image_archive(args.target)
            target_dir = resolve_detect_image_output_dir(args.target)
            detect_url = (
                f"{base_url}/commands/detect_image"
                f"?filename={urllib.parse.quote(archive_path.name)}"
            )
            result = request_detect_image(
                archive_file=archive_path,
                url=detect_url,
                token=token,
                timeout=DETECT_IMAGE_REQUEST_TIMEOUT,
                target_dir=target_dir,
            )
        finally:
            if cleanup_dir is not None:
                shutil.rmtree(cleanup_dir, ignore_errors=True)
    elif args.name == "detect_images":
        if not args.target:
            raise SystemExit(
                "detect_images 命令需要提供包含多套原图的目录，例如：eve detect_images /path/cases"
            )
        detect_url = f"{base_url}/commands/detect_image"
        result = request_detect_images(
            target=args.target,
            url=detect_url,
            token=token,
            timeout=DETECT_IMAGE_REQUEST_TIMEOUT,
        )
    else:
        if args.target:
            raise SystemExit(f"{args.name} 命令不接受额外文件路径参数")
        try:
            payload = json.loads(args.data)
        except json.JSONDecodeError as exc:
            raise SystemExit(f"--data 必须是合法的 JSON 对象字符串: {exc}") from exc
        if not isinstance(payload, dict):
            raise SystemExit("--data 解析后必须是 JSON 对象")
        result = request_json("POST", f"{base_url}/commands/{args.name}", payload, token=token)

    print_json(result)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except RuntimeError as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
